package model;

public class Professor {

    private String name;
    private String id;

    public Professor(String name, String id) {
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }
}