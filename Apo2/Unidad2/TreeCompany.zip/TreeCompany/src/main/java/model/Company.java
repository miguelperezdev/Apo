package model;

public class Company {

    private String name;
    private Employee root;

    public Company(String name) {
        this.name = name;
        addIte("5","juan",5);
        addIte("3","jose",3);
        addIte("6","isabella",6);
        addIte("1","andres",1);
        addIte("4","edward",4);
    }

    public String getName() {
        return name;
    }

    public Employee getRoot() {
        return root;
    }

    public void add(String id, String name, int off){
        Employee emp = new Employee(id, name, off);
        add(root, emp);
    }

    private void add(Employee currentRoot, Employee newEmp){
        //Caso base
        if(currentRoot == null){
            root = newEmp;
        }
        else{
            //Caso recursivo 1: El nuevo nodo es menor
            if(currentRoot.compareTo(newEmp)==1){
                if(currentRoot.getLeft()==null){
                    currentRoot.setLeft(newEmp);
                    newEmp.setParent(currentRoot);
                }
                else{
                    add(currentRoot.getLeft(),newEmp);
                }
            }
            //Caso recursivo 2: El nuevo nodo es mayor
            else if(currentRoot.compareTo(newEmp)==-1){
                if(currentRoot.getRight()==null){
                    currentRoot.setRight(newEmp);
                    newEmp.setParent(currentRoot);
                }
                else{
                    add(currentRoot.getRight(),newEmp);
                }
            }
        }
    }

    public void addIte(String id, String name, int off){
        Employee newEmp = new Employee(id, name, off);
        //Caso base
        if(root == null){
            root = newEmp;
        }
        else{

            Employee currentRoot = root;
            boolean added = false;
            while(currentRoot!=null && !added) {
                //Caso Iterativo 1: El nuevo nodo es menor
                if (currentRoot.compareTo(newEmp) == 1) {
                    if (currentRoot.getLeft() == null) {
                        currentRoot.setLeft(newEmp);
                        newEmp.setParent(currentRoot);
                        added=true;
                    }
                    currentRoot = currentRoot.getLeft();
                    //Caso Iterativo 2: El nuevo nodo es mayor
                } else if (currentRoot.compareTo(newEmp) == -1) {
                    if (currentRoot.getRight() == null) {
                        currentRoot.setRight(newEmp);
                        newEmp.setParent(currentRoot);
                        added=true;
                    }
                    currentRoot = currentRoot.getRight();
                }
            }
        }
    }

    public Employee search(String ident){
        return search(ident, root);
    }

    private Employee search(String ident, Employee currentRoot){
        //Caso base
        if(currentRoot.getId().equals(ident)){
            return currentRoot;
        }
        else{
            //Caso recursivo 1: El nodo a buscar es menor
            if(currentRoot.getId().compareTo(ident)==1){
                search(ident, currentRoot.getLeft());
            }
            //Caso recursivo 2: El nodo a buscar es mayor
            else if(currentRoot.getId().compareTo(ident)==-1){
                search(ident, currentRoot.getRight());
            }
        }
        return null;
    }

    public Employee searchIte(String ident){
        if(root.getId().equals(ident)){
            return root;
        }
        else{
            Employee currentRoot = root;
            while(currentRoot!=null) {
                //Caso Iterativo 1: El nuevo nodo es menor
                if (currentRoot.getId().compareTo(ident) == 1) {
                    if (currentRoot.getId().equals(ident)) {
                        return currentRoot;
                    }
                    currentRoot = currentRoot.getLeft();
                    //Caso Iterativo 2: El nuevo nodo es mayor
                } else if (currentRoot.getId().compareTo(ident) == -1) {
                    if (currentRoot.getId().equals(ident)) {
                        return currentRoot;
                    }
                    currentRoot = currentRoot.getRight();
                }
            }
        }
        return null;
    }

    public Employee remove(String ident){
        Employee empRem = search(ident);
        remove(empRem);
        return empRem;
    }

    private void remove(Employee empRem){
        //Caso 1: El nodo a eliminar es una hoja
        if(empRem.getRight()==null && empRem.getLeft()==null){
            Employee temp = empRem.getParent();
            if(temp.compareTo(empRem)==1){
                temp.setLeft(null);
            }
            else if(temp.compareTo(empRem)==-1){
                temp.setRight(null);
            }
        }
    }
}
