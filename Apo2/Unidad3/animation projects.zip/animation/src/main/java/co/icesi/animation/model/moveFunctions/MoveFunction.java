package co.icesi.animation.model.moveFunctions;

public interface MoveFunction {

    public double move(double x, double ... params);
}
