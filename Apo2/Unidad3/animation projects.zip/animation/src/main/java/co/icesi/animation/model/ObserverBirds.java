package co.icesi.animation.model;

public interface ObserverBirds {
    void update();
}
