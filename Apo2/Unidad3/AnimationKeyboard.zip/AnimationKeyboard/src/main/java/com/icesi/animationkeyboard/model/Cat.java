package com.icesi.animationkeyboard.model;

public class Cat {
}
