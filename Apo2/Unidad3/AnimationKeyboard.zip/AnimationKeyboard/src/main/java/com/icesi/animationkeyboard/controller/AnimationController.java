package com.icesi.animationkeyboard.controller;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;

public class AnimationController {

    @FXML
    private Canvas canvas;

}
