module com.icesi.animationkeyboard {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.icesi.animationkeyboard to javafx.fxml;
    exports com.icesi.animationkeyboard;
}